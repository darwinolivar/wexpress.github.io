$(function(){
    $(".sidenav-toggle a").on("click", function (){
        $("body").toggleClass("panel--togggle")
    });
    
     $('.panel--togggle[data-toggle="tooltip"]').tooltip(); 
});